package com.gymmanagement.controller;
import com.gymmanagement.entity.Payment;
import com.gymmanagement.dto.DashboardSummary;
import com.gymmanagement.entity.Member;
import com.gymmanagement.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin(origins = {
        "http://localhost:5173",
        "http://localhost:5174"
})
public class DashboardController {
    @GetMapping("/dashboard/recent-members")
    public List<Member> getRecentMembers() {
        return dashboardService.getRecentMembers();
    }
    @GetMapping("/dashboard/recent-payments")
    public List<Payment> getRecentPayments() {
        return dashboardService.getRecentPayments();
    }

    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/dashboard/summary")
    public DashboardSummary getDashboardSummary() {
        return dashboardService.getDashboardSummary();
    }
}